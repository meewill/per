# dev-tools-style
A Chrome plugin for customizing the style of dev tools

### Screenshots
<img width="1524" alt="Screen Shot 2022-10-19 at 11 55 54 PM" src="https://user-images.githubusercontent.com/50689806/196742977-68142fd3-528e-4c44-a8ac-9919462dd00a.png">

<img width="1524" alt="Screen Shot 2022-10-19 at 11 34 58 PM" src="https://user-images.githubusercontent.com/50689806/196737918-6211af4a-5770-4080-8184-5a3f97b8918b.png">

> You need to turn on "Allow extensions to load custom stylesheets" in the Experiments page.
<img width="848" alt="Screen Shot 2022-10-16 at 11 52 16 AM" src="https://user-images.githubusercontent.com/50689806/196017461-ce93a3dd-6980-4f6b-9b22-a80c68a86f41.png">
